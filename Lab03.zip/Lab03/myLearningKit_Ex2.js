/* 22f 1012 JS files */
function p01Func() {
	
  /* in Ex1, set message text and image sources for problem01 */
  
 document.getElementById("problem").innerHTML="<p>Chess is a board game for two players. It is sometimes called Western chess or international chess. The current form of the game emerged in Spain and the rest of Southern Europe during the second half of the 15th century after evolving from chaturange, a similar but much older game of Indian origin.</p>"
 
 document.getElementById("flowchart").src = "images/Chess/ChessSet.jpg";
 document.getElementById("js").src = "images/Chess/park-chess.jpg";
 document.getElementById("another").src = "images/Chess/chess-another.jpg";
  /* the following three lines gets the checkboxes, and unchecks them
  */
  document.getElementById("check1").checked=false;
  document.getElementById("check2").checked=false;
  document.getElementById("check3").checked=false;

  /* in Ex3, update display of images */


}


/* in Ex2, uncomment the following function and complete it*/


function checkUncheck1(){
  if (document.getElementById("check1").checked==true) {

   document.getElementById("flowchart").style.display = "inline";
	 
  }
  else {
   document.getElementById("flowchart").style.display = "none";
	  
  }
}


function checkUncheck2(){
   if (document.getElementById("check2").checked==true) {
 
   document.getElementById("js").style.display = "inline";
	 
   }
   else {
    document.getElementById("js").style.display = "none";
      
   }
 }

function checkUncheck3(){
   if (document.getElementById("check3").checked==true) {
 
    document.getElementById("another").style.display = "inline";
     
   }
   else {
    document.getElementById("another").style.display = "none";
      
   }
 }
 



/* in Ex3, create function p02Func similar to p01Func */

/* in Ex4, create functions zoomIn() and zoomOut() */
