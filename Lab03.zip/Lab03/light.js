/* 22f Task 1 - write your code here */
function on_1() {
  document.getElementById("message").innerHTML = "Light #1 is on";
  document.getElementById("light").src = "images/light/light_1.jpg"
}

function on_2() {
    document.getElementById("message").innerHTML = "Light #2 is on";
    document.getElementById("light").src = "images/light/light_2.jpg"
}

function on_3() {
    document.getElementById("message").innerHTML = "Light #3 is on";
    document.getElementById("light").src = "images/light/light_3.jpg"
}

function on_4() {
    document.getElementById("message").innerHTML = "Light #4 is on";
    document.getElementById("light").src = "images/light/light_4.jpg"
}

function on_5() {
    document.getElementById("message").innerHTML = "Light #5 is on";
    document.getElementById("light").src = "images/light/light_5.jpg"
}




/* implement function oFF() for switching off the light*/
function oFF(){
    
}
